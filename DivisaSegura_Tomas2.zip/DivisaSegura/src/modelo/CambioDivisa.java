package modelo;

public class CambioDivisa extends Transaccion {
    private String divisaOrigen;
    private String divisaDestino;
    private double montoOrigen;
    private double tasa;
    private double montoDestino;
    private double comision;

    public CambioDivisa(String id, String fechaHora, Cliente cliente,
                        Empleado empleado, String estado,
                        String divisaOrigen, String divisaDestino,
                        double montoOrigen, double tasa,
                        double montoDestino, double comision) {
        super(id, fechaHora, cliente, empleado, estado);
        this.divisaOrigen = divisaOrigen;
        this.divisaDestino = divisaDestino;
        this.montoOrigen = montoOrigen;
        this.tasa = tasa;
        this.montoDestino = montoDestino;
        this.comision = comision;
    }

    public String getDivisaOrigen() {
        return divisaOrigen;
    }

    public String getDivisaDestino() {
        return divisaDestino;
    }

    public double getMontoOrigen() {
        return montoOrigen;
    }

    public double getTasa() {
        return tasa;
    }

    public double getMontoDestino() {
        return montoDestino;
    }

    public double getComision() {
        return comision;
    }

    @Override
    public double getMontoEquivalenteCOP() {
        if (divisaOrigen.equalsIgnoreCase("COP")) {
            return montoOrigen;
        }
        if (divisaDestino.equalsIgnoreCase("COP")) {
            return montoDestino;
        }

        // Para pares distintos de COP, el equivalente COP debe calcularse
        // con la tasa de conversión a COP correspondiente del sistema.
        // Esta transacción solo almacena la tasa aplicada al par negociado.
        return 0.0;
    }

    @Override
    public boolean esEfectiva() {
        return estado.equalsIgnoreCase("COMPLETADA");
    }

    @Override
    public String toLinea() {
        return "CAMBIO;" + id + ";" + fechaHora + ";"
                + cliente.getId() + ";" + empleado.getId() + ";"
                + divisaOrigen + ";" + divisaDestino + ";"
                + montoOrigen + ";" + tasa + ";" + montoDestino + ";"
                + comision + ";" + estado;
    }

    @Override
    public String mostrarDetalle() {
        return super.mostrarDetalle()
                + " | Cambio: " + montoOrigen + " " + divisaOrigen
                + " a " + montoDestino + " " + divisaDestino
                + " | Tasa: " + tasa
                + " | Comisión: " + comision;
    }
}
