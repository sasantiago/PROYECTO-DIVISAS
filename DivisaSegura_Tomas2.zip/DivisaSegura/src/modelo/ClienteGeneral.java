package modelo;

public class ClienteGeneral extends Cliente {

    public ClienteGeneral(String id, String nombre) {
        super(id, nombre);
    }

    @Override
    public double getPorcentajeComision() {
        return 0.015;
    }

    @Override
    public double getMontoMinimoUSD() {
        return 10.0;
    }

    @Override
    public String getTipo() {
        return "GENERAL";
    }
}
