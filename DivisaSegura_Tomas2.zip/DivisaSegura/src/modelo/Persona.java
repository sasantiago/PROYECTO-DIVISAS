package modelo;

public abstract class Persona {
    protected String id;
    protected String nombre;

    public Persona(String id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public abstract String getRol();

    @Override
    public String toString() {
        return "ID: " + id + " | Nombre: " + nombre + " | Rol: " + getRol();
    }
}
