package modelo;

public abstract class Empleado extends Persona {
    protected int operacionesAtendidas;

    public Empleado(String id, String nombre) {
        super(id, nombre);
        operacionesAtendidas = 0;
    }

    public boolean puedeActualizarTasas() {
        return false;
    }

    public boolean puedeCerrarTurno() {
        return false;
    }

    public void registrarOperacionAtendida() {
        operacionesAtendidas++;
    }

    public int getOperacionesAtendidas() {
        return operacionesAtendidas;
    }
}
