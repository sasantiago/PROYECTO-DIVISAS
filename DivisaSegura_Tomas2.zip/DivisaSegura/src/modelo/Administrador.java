package modelo;

public class Administrador extends Empleado {

    public Administrador(String id, String nombre) {
        super(id, nombre);
    }

    @Override
    public boolean puedeActualizarTasas() {
        return true;
    }

    @Override
    public boolean puedeCerrarTurno() {
        return true;
    }

    @Override
    public String getRol() {
        return "ADMINISTRADOR";
    }
}
