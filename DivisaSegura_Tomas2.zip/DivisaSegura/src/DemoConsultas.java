import estructuras.Cola;
import estructuras.Lista;
import estructuras.Pila;
import modelo.*;
import negocio.Caja;
import negocio.Consultas;
import negocio.Tasa;

public class DemoConsultas {
    public static void main(String[] args) {
        Cliente laura = new ClienteGeneral("C001", "Laura Gomez");
        Cliente carlos = new ClientePreferencial("C002", "Carlos Ruiz");
        Cliente textiles = new ClienteEmpresarial("C003", "Textiles del Valle SAS", "900123456-7");
        Empleado ana = new Cajero("E01", "Ana Torres");

        Lista<Cliente> clientes = new Lista<>();
        clientes.agregar(laura);
        clientes.agregar(carlos);
        clientes.agregar(textiles);

        Lista<Tasa> tasas = new Lista<>();
        tasas.agregar(new Tasa("USD", "COP", 4150.50));
        tasas.agregar(new Tasa("EUR", "COP", 4520.00));
        tasas.agregar(new Tasa("GBP", "COP", 5230.75));
        tasas.agregar(new Tasa("MXN", "COP", 215.30));

        Caja caja = new Caja(100000000, 10000, 10000, 100000, 10000);

        Lista<Transaccion> lista = new Lista<>();
        Pila<Transaccion> pila = new Pila<>();

        CambioDivisa t1 = new CambioDivisa("T001", "2026-10-20 09:15", laura, ana, "COMPLETADA",
                "USD", "COP", 100, 4150.50, 415050, 6225.75);
        CambioDivisa t2 = new CambioDivisa("T002", "2026-10-20 09:22", textiles, ana, "COMPLETADA",
                "EUR", "COP", 1000, 4520.00, 4520000, 36160.00);
        CambioDivisa t4 = new CambioDivisa("T004", "2026-10-20 10:05", carlos, ana, "COMPLETADA",
                "USD", "COP", 200, 4150.50, 830100, 8301.00);
        CambioDivisa t5 = new CambioDivisa("T005", "2026-10-20 10:30", laura, ana, "COMPLETADA",
                "MXN", "COP", 5000, 215.30, 1076500, 16147.50);
        CambioDivisa t6 = new CambioDivisa("T006", "2026-10-20 11:00", carlos, ana, "RECHAZADA",
                "EUR", "COP", 10000, 4520.00, 45200000, 0);

        CambioDivisa[] completadas = {t1, t2, t4, t5};
        for (int i = 0; i < completadas.length; i++) {
            CambioDivisa c = completadas[i];
            lista.agregar(c);
            pila.apilar(c);
            caja.actualizarSaldo(c.getDivisaOrigen(), c.getMontoOrigen());
            caja.actualizarSaldo(c.getDivisaDestino(), -c.getMontoDestino());
        }
        lista.agregar(t6);

        Consultas.marcarComoReversada(lista, "T001");
        caja.restituir("USD", "COP", 100, 415050);
        lista.agregar(new Reversion("T003", "2026-10-20 09:40", laura, ana, "T001", "Error de digitacion"));

        Cola<Cliente> colaPreferencial = new Cola<>();
        Cola<Cliente> colaGeneral = new Cola<>();
        colaPreferencial.encolar(carlos);
        colaGeneral.encolar(laura);
        colaGeneral.encolar(textiles);

        Consultas.consulta1(colaPreferencial, colaGeneral, 0);
        Consultas.consulta2(lista, laura);
        Consultas.consulta3(lista, tasas);
        Consultas.consulta4(lista);
        Consultas.consulta5(lista);
        Consultas.consulta6(caja);
        Consultas.consulta7(lista);
        Consultas.consulta8(lista);
        Consultas.consulta9(lista, "09:20", "10:10");
        Consultas.consulta10("datos/historial_tasas.txt", "USD", "COP", "2026-10-20");
        Consultas.consulta11(lista);
        Consultas.consulta12(clientes, lista);

        System.out.println();
        System.out.println("Caso 9 (EUR a MXN con COP de puente): 100 EUR = "
                + String.format("%.2f", Consultas.convertir(100, "EUR", "MXN", tasas)) + " MXN");
    }
}
