import estructuras.Cola;
import estructuras.Lista;
import estructuras.Nodo;
import estructuras.Pila;
import modelo.*;
import negocio.Consultas;

public class CasosDePruebaEstructuras {
    public static void main(String[] args) {
        System.out.println("======================================");
        System.out.println(" PRUEBAS ESTRUCTURAS - DIVISASEGURA");
        System.out.println("======================================");

        caso1();
        caso5();
        caso10();
        pruebaFifoLifo();
        pruebaOrdenarPorMonto();

        System.out.println("\nPruebas finalizadas.");
    }

    public static void caso1() {
        System.out.println("\nCASO 1 - ATENDER CON LA COLA VACIA");

        Cola<Cliente> cola = new Cola<>();
        Cliente atendido = cola.desencolar();

        if (atendido == null) {
            System.out.println("Mensaje: No hay clientes en la cola de atencion.");
        }
        comprobar("desencolar() devuelve null", atendido == null, true);
        comprobar("frente() devuelve null", cola.frente() == null, true);
        comprobar("estaVacia()", cola.estaVacia(), true);
        comprobarNumero("tamano()", cola.tamano(), 0);
    }

    public static void caso5() {
        System.out.println("\nCASO 5 - DESHACER CON LA PILA VACIA");

        Pila<Transaccion> pila = new Pila<>();
        Transaccion deshecha = pila.desapilar();

        if (deshecha == null) {
            System.out.println("Mensaje: No hay operaciones para deshacer.");
        }
        comprobar("desapilar() devuelve null", deshecha == null, true);
        comprobar("cima() devuelve null", pila.cima() == null, true);
        comprobar("estaVacia()", pila.estaVacia(), true);
        comprobarNumero("tamano()", pila.tamano(), 0);
    }

    public static void caso10() {
        System.out.println("\nCASO 10 - ELIMINAR PRIMERA, INTERMEDIA Y ULTIMA");

        Cliente cliente = new ClienteGeneral("C001", "Laura Gomez");
        Empleado cajero = new Cajero("E01", "Ana Torres");

        Lista<Transaccion> lista1 = crearListaDeCinco(cliente, cajero);
        lista1.eliminar(0);
        comprobarTexto("Eliminar la primera", ids(lista1), "T002,T003,T004,T005");
        comprobarNumero("tamano", lista1.tamano(), 4);

        Lista<Transaccion> lista2 = crearListaDeCinco(cliente, cajero);
        lista2.eliminar(2);
        comprobarTexto("Eliminar una intermedia (T003)", ids(lista2), "T001,T002,T004,T005");
        comprobarNumero("tamano", lista2.tamano(), 4);

        Lista<Transaccion> lista3 = crearListaDeCinco(cliente, cajero);
        lista3.eliminar(4);
        comprobarTexto("Eliminar la ultima", ids(lista3), "T001,T002,T003,T004");
        comprobarNumero("tamano", lista3.tamano(), 4);

        lista3.agregar(crearCambio("T006", cliente, cajero));
        comprobarTexto("Agregar despues de eliminar la ultima", ids(lista3), "T001,T002,T003,T004,T006");

        Lista<Transaccion> lista4 = crearListaDeCinco(cliente, cajero);
        Transaccion inexistente = lista4.eliminar(99);
        comprobar("Eliminar una posicion que no existe devuelve null", inexistente == null, true);
        comprobarNumero("tamano no cambia", lista4.tamano(), 5);

        Lista<Transaccion> lista5 = new Lista<>();
        lista5.agregar(crearCambio("T001", cliente, cajero));
        lista5.eliminar(0);
        lista5.agregar(crearCambio("T002", cliente, cajero));
        comprobarTexto("Eliminar el unico elemento y volver a agregar", ids(lista5), "T002");
    }

    public static void pruebaFifoLifo() {
        System.out.println("\nEXTRA - FIFO, LIFO Y CIMA");

        Cola<String> cola = new Cola<>();
        cola.encolar("A");
        cola.encolar("B");
        cola.encolar("C");
        comprobarTexto("Cola: primero que sale", cola.desencolar(), "A");
        comprobarTexto("Cola: segundo que sale", cola.desencolar(), "B");

        Pila<String> pila = new Pila<>();
        pila.apilar("A");
        pila.apilar("B");
        pila.apilar("C");
        comprobarTexto("Pila: cima (sin sacar)", pila.cima(), "C");
        comprobarNumero("Pila: tamano despues de cima", pila.tamano(), 3);
        comprobarTexto("Pila: primero que sale", pila.desapilar(), "C");
        comprobarNumero("Pila: tamano despues de desapilar", pila.tamano(), 2);
    }

    public static void pruebaOrdenarPorMonto() {
        System.out.println("\nEXTRA - ORDENAR POR MONTO");

        Cliente cliente = new ClienteGeneral("C001", "Laura Gomez");
        Empleado cajero = new Cajero("E01", "Ana Torres");

        Lista<Transaccion> lista = new Lista<>();
        lista.agregar(crearCambioConMonto("T001", cliente, cajero, 100));
        lista.agregar(crearCambioConMonto("T002", cliente, cajero, 500));
        lista.agregar(crearCambioConMonto("T003", cliente, cajero, 300));
        lista.agregar(crearCambioConMonto("T004", cliente, cajero, 200));

        Lista<Transaccion> ordenada = Consultas.ordenarPorMonto(lista);
        comprobarTexto("Orden de mayor a menor", ids(ordenada), "T002,T003,T004,T001");
        comprobarTexto("La lista original no cambia", ids(lista), "T001,T002,T003,T004");
    }

    private static Transaccion crearCambio(String id, Cliente cliente, Empleado cajero) {
        return crearCambioConMonto(id, cliente, cajero, 100);
    }

    private static Transaccion crearCambioConMonto(String id, Cliente cliente, Empleado cajero,
                                                   double montoUSD) {
        double tasa = 4150.50;
        double montoDestino = montoUSD * tasa;
        double comision = cliente.calcularComision(montoDestino);
        return new CambioDivisa(id, "2026-10-20 09:00", cliente, cajero, "COMPLETADA",
                "USD", "COP", montoUSD, tasa, montoDestino, comision);
    }

    private static Lista<Transaccion> crearListaDeCinco(Cliente cliente, Empleado cajero) {
        Lista<Transaccion> lista = new Lista<>();
        lista.agregar(crearCambio("T001", cliente, cajero));
        lista.agregar(crearCambio("T002", cliente, cajero));
        lista.agregar(crearCambio("T003", cliente, cajero));
        lista.agregar(crearCambio("T004", cliente, cajero));
        lista.agregar(crearCambio("T005", cliente, cajero));
        return lista;
    }

    private static String ids(Lista<Transaccion> lista) {
        String texto = "";
        Nodo<Transaccion> actual = lista.getCabeza();
        while (actual != null) {
            texto = texto + actual.getDato().getId();
            if (actual.getSiguiente() != null) {
                texto = texto + ",";
            }
            actual = actual.getSiguiente();
        }
        return texto;
    }

    private static void comprobar(String prueba, boolean obtenido, boolean esperado) {
        System.out.println(prueba + ": obtenido = " + obtenido
                + " | esperado = " + esperado
                + " -> " + (obtenido == esperado ? "CORRECTO" : "ERROR"));
    }

    private static void comprobarNumero(String prueba, int obtenido, int esperado) {
        System.out.println(prueba + ": obtenido = " + obtenido
                + " | esperado = " + esperado
                + " -> " + (obtenido == esperado ? "CORRECTO" : "ERROR"));
    }

    private static void comprobarTexto(String prueba, String obtenido, String esperado) {
        System.out.println(prueba + ": obtenido = " + obtenido
                + " | esperado = " + esperado
                + " -> " + (obtenido.equals(esperado) ? "CORRECTO" : "ERROR"));
    }
}
