package negocio;

public class Tasa {
    private String divisaOrigen;
    private String divisaDestino;
    private double valor;

    public Tasa(String divisaOrigen, String divisaDestino, double valor) {
        this.divisaOrigen = divisaOrigen;
        this.divisaDestino = divisaDestino;
        this.valor = valor;
    }

    public String getDivisaOrigen() {
        return divisaOrigen;
    }

    public String getDivisaDestino() {
        return divisaDestino;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        if (valor > 0) {
            this.valor = valor;
        }
    }

    public double convertir(double monto) {
        if (monto <= 0) {
            return 0;
        }
        return monto * valor;
    }

    public String toLinea() {
        return divisaOrigen + ";" + divisaDestino + ";" + valor;
    }
}
