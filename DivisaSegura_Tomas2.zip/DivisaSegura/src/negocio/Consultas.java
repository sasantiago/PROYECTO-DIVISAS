package negocio;

import estructuras.Cola;
import estructuras.Lista;
import estructuras.Nodo;
import modelo.CambioDivisa;
import modelo.Cliente;
import modelo.ClienteEmpresarial;
import modelo.Reversion;
import modelo.Transaccion;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Consultas {
    private static final String LINEA = "================================================================";
    private static final String[] DIVISAS = {"COP", "USD", "EUR", "MXN", "GBP"};

    private static String formato(double valor) {
        return String.format("%,.2f", valor);
    }

    private static void titulo(String texto) {
        System.out.println();
        System.out.println(LINEA);
        System.out.println(texto);
        System.out.println(LINEA);
    }

    public static Transaccion buscarPorId(Lista<Transaccion> lista, String id) {
        Nodo<Transaccion> actual = lista.getCabeza();
        while (actual != null) {
            if (actual.getDato().getId().equals(id)) {
                return actual.getDato();
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

    public static Lista<Transaccion> listarPorCliente(Lista<Transaccion> lista, String idCliente) {
        Lista<Transaccion> resultado = new Lista<>();
        Nodo<Transaccion> actual = lista.getCabeza();
        while (actual != null) {
            if (actual.getDato().getCliente().getId().equals(idCliente)) {
                resultado.agregar(actual.getDato());
            }
            actual = actual.getSiguiente();
        }
        return resultado;
    }

    public static Lista<Transaccion> listarPorEstado(Lista<Transaccion> lista, String estado) {
        Lista<Transaccion> resultado = new Lista<>();
        Nodo<Transaccion> actual = lista.getCabeza();
        while (actual != null) {
            if (actual.getDato().getEstado().equals(estado)) {
                resultado.agregar(actual.getDato());
            }
            actual = actual.getSiguiente();
        }
        return resultado;
    }

    public static Lista<Cliente> listarPorTipoCliente(Lista<Cliente> clientes, String tipo) {
        Lista<Cliente> resultado = new Lista<>();
        Nodo<Cliente> actual = clientes.getCabeza();
        while (actual != null) {
            if (actual.getDato().getTipo().equals(tipo)) {
                resultado.agregar(actual.getDato());
            }
            actual = actual.getSiguiente();
        }
        return resultado;
    }

    public static boolean marcarComoReversada(Lista<Transaccion> lista, String id) {
        Transaccion t = buscarPorId(lista, id);
        if (t == null || !t.esEfectiva()) {
            return false;
        }
        t.setEstado("REVERSADA");
        return true;
    }

    public static double totalPorDivisa(Lista<Transaccion> lista, String divisa) {
        double total = 0;
        Nodo<Transaccion> actual = lista.getCabeza();
        while (actual != null) {
            Transaccion t = actual.getDato();
            if (t instanceof CambioDivisa && t.esEfectiva()) {
                CambioDivisa cambio = (CambioDivisa) t;
                if (cambio.getDivisaOrigen().equals(divisa)) {
                    total = total + cambio.getMontoOrigen();
                }
            }
            actual = actual.getSiguiente();
        }
        return total;
    }

    private static Tasa buscarTasa(Lista<Tasa> tasas, String origen, String destino) {
        Nodo<Tasa> actual = tasas.getCabeza();
        while (actual != null) {
            Tasa t = actual.getDato();
            if (t.getDivisaOrigen().equals(origen) && t.getDivisaDestino().equals(destino)) {
                return t;
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

    public static double convertir(double monto, String origen, String destino, Lista<Tasa> tasas) {
        if (origen.equals(destino)) {
            return monto;
        }
        Tasa directa = buscarTasa(tasas, origen, destino);
        if (directa != null) {
            return directa.convertir(monto);
        }

        double enCOP;
        if (origen.equals("COP")) {
            enCOP = monto;
        } else {
            Tasa origenACOP = buscarTasa(tasas, origen, "COP");
            if (origenACOP == null) {
                return -1;
            }
            enCOP = origenACOP.convertir(monto);
        }

        if (destino.equals("COP")) {
            return enCOP;
        }
        Tasa destinoACOP = buscarTasa(tasas, destino, "COP");
        if (destinoACOP == null) {
            return -1;
        }
        return enCOP / destinoACOP.getValor();
    }

    public static Lista<Transaccion> ordenarPorMonto(Lista<Transaccion> lista) {
        Lista<Transaccion> ordenada = new Lista<>();
        Nodo<Transaccion> actual = lista.getCabeza();
        while (actual != null) {
            Transaccion t = actual.getDato();
            if (t.esEfectiva()) {
                int posicion = 0;
                Nodo<Transaccion> recorrido = ordenada.getCabeza();
                while (recorrido != null
                        && recorrido.getDato().getMontoEquivalenteCOP() >= t.getMontoEquivalenteCOP()) {
                    posicion++;
                    recorrido = recorrido.getSiguiente();
                }
                ordenada.insertarEn(posicion, t);
            }
            actual = actual.getSiguiente();
        }
        return ordenada;
    }

    public static Transaccion mayorTransaccion(Lista<Transaccion> lista) {
        Transaccion mayor = null;
        Nodo<Transaccion> actual = lista.getCabeza();
        while (actual != null) {
            Transaccion t = actual.getDato();
            if (t.esEfectiva()) {
                if (mayor == null || t.getMontoEquivalenteCOP() > mayor.getMontoEquivalenteCOP()) {
                    mayor = t;
                }
            }
            actual = actual.getSiguiente();
        }
        return mayor;
    }

    private static int contarOperaciones(Lista<Transaccion> lista, String idCliente) {
        int cuenta = 0;
        Nodo<Transaccion> actual = lista.getCabeza();
        while (actual != null) {
            Transaccion t = actual.getDato();
            if (t instanceof CambioDivisa && t.getCliente().getId().equals(idCliente)) {
                cuenta++;
            }
            actual = actual.getSiguiente();
        }
        return cuenta;
    }

    private static int totalOperaciones(Lista<Transaccion> lista) {
        int cuenta = 0;
        Nodo<Transaccion> actual = lista.getCabeza();
        while (actual != null) {
            if (actual.getDato() instanceof CambioDivisa) {
                cuenta++;
            }
            actual = actual.getSiguiente();
        }
        return cuenta;
    }

    public static Cliente clienteMasFrecuente(Lista<Transaccion> lista) {
        Cliente mejor = null;
        int mejorCuenta = 0;
        Nodo<Transaccion> actual = lista.getCabeza();
        while (actual != null) {
            Transaccion t = actual.getDato();
            if (t instanceof CambioDivisa) {
                int cuenta = contarOperaciones(lista, t.getCliente().getId());
                if (cuenta > mejorCuenta) {
                    mejorCuenta = cuenta;
                    mejor = t.getCliente();
                }
            }
            actual = actual.getSiguiente();
        }
        return mejor;
    }

    public static Lista<Transaccion> transaccionesEnRango(Lista<Transaccion> lista,
                                                          String desde, String hasta) {
        Lista<Transaccion> resultado = new Lista<>();
        Nodo<Transaccion> actual = lista.getCabeza();
        while (actual != null) {
            Transaccion t = actual.getDato();
            if (t.getFechaHora().length() >= 16) {
                String hora = t.getFechaHora().substring(11, 16);
                if (hora.compareTo(desde) >= 0 && hora.compareTo(hasta) <= 0) {
                    resultado.agregar(t);
                }
            }
            actual = actual.getSiguiente();
        }
        return resultado;
    }

    public static double comisionesPorTipo(Lista<Transaccion> lista, String tipo) {
        double total = 0;
        Nodo<Transaccion> actual = lista.getCabeza();
        while (actual != null) {
            Transaccion t = actual.getDato();
            if (t instanceof CambioDivisa && t.esEfectiva()
                    && t.getCliente().getTipo().equals(tipo)) {
                CambioDivisa cambio = (CambioDivisa) t;
                total = total + t.getCliente().calcularComision(cambio.getMontoDestino());
            }
            actual = actual.getSiguiente();
        }
        return total;
    }

    public static Cliente quienSigue(Cola<Cliente> preferencial, Cola<Cliente> general,
                                     int preferencialesSeguidos) {
        if (!preferencial.estaVacia() && (preferencialesSeguidos < 2 || general.estaVacia())) {
            return preferencial.frente();
        }
        return general.frente();
    }

    public static void mostrarCola(String nombre, Cola<Cliente> cola) {
        System.out.println(nombre + " (" + cola.tamano() + "):");
        if (cola.estaVacia()) {
            System.out.println("   (vacia)");
            return;
        }
        int posicion = 1;
        Nodo<Cliente> actual = cola.getNodoFrente();
        while (actual != null) {
            Cliente c = actual.getDato();
            System.out.println("   " + posicion + ". " + c.getId() + " - " + c.getNombre()
                    + " [" + c.getTipo() + "]");
            actual = actual.getSiguiente();
            posicion++;
        }
    }

    public static void consulta1(Cola<Cliente> preferencial, Cola<Cliente> general,
                                 int preferencialesSeguidos) {
        titulo("C1 - ESTADO DE LA FILA DE ESPERA");
        int total = preferencial.tamano() + general.tamano();
        if (total == 0) {
            System.out.println("No hay clientes en espera.");
            return;
        }
        Cliente siguiente = quienSigue(preferencial, general, preferencialesSeguidos);
        System.out.println("Clientes en espera: " + total);
        System.out.println("Sigue: " + siguiente.getNombre() + " [" + siguiente.getTipo() + "]");
        mostrarCola("Cola preferencial", preferencial);
        mostrarCola("Cola general", general);
    }

    public static void consulta2(Lista<Transaccion> lista, Cliente cliente) {
        titulo("C2 - HISTORIAL DEL CLIENTE " + cliente.getId() + " - " + cliente.getNombre());
        Lista<Transaccion> propias = listarPorCliente(lista, cliente.getId());
        if (propias.estaVacia()) {
            System.out.println("El cliente no tiene operaciones.");
            return;
        }
        Nodo<Transaccion> actual = propias.getCabeza();
        while (actual != null) {
            System.out.println(actual.getDato().toLinea());
            actual = actual.getSiguiente();
        }
        System.out.println("Total entregado por divisa (solo COMPLETADAS):");
        for (int i = 0; i < DIVISAS.length; i++) {
            double total = totalPorDivisa(propias, DIVISAS[i]);
            if (total > 0) {
                System.out.println("   " + DIVISAS[i] + ": " + formato(total));
            }
        }
    }

    public static void consulta3(Lista<Transaccion> lista, Lista<Tasa> tasas) {
        titulo("C3 - DIVISA CON MAYOR VOLUMEN DEL DIA (en COP)");
        String mejorDivisa = null;
        double mejorVolumen = 0;
        for (int i = 0; i < DIVISAS.length; i++) {
            double total = totalPorDivisa(lista, DIVISAS[i]);
            double enCOP = convertir(total, DIVISAS[i], "COP", tasas);
            System.out.println("   " + DIVISAS[i] + ": " + formato(total) + " -> "
                    + formato(enCOP) + " COP");
            if (enCOP > mejorVolumen) {
                mejorVolumen = enCOP;
                mejorDivisa = DIVISAS[i];
            }
        }
        if (mejorDivisa == null) {
            System.out.println("No hay operaciones completadas.");
        } else {
            System.out.println("Mayor volumen: " + mejorDivisa + " con " + formato(mejorVolumen) + " COP");
        }
    }

    public static void consulta4(Lista<Transaccion> lista) {
        titulo("C4 - TRANSACCIONES REVERSADAS DEL TURNO");
        Lista<Transaccion> reversadas = listarPorEstado(lista, "REVERSADA");
        int cantidad = 0;
        Nodo<Transaccion> actual = reversadas.getCabeza();
        while (actual != null) {
            Transaccion t = actual.getDato();

            if (t instanceof CambioDivisa) {
                cantidad++;
                System.out.println("   " + t.getId() + " | Cliente: " + t.getCliente().getId()
                        + " - " + t.getCliente().getNombre());
            }
            actual = actual.getSiguiente();
        }
        if (cantidad == 0) {
            System.out.println("No hubo reversiones en el turno.");
            return;
        }
        System.out.println("Total reversadas: " + cantidad);

        System.out.println("Detalle de las reversiones:");
        Nodo<Transaccion> recorrido = lista.getCabeza();
        while (recorrido != null) {
            if (recorrido.getDato() instanceof Reversion) {
                Reversion r = (Reversion) recorrido.getDato();
                Transaccion original = buscarPorId(lista, r.getIdOriginal());
                if (original != null) {
                    System.out.println("   " + r.getId() + " revierte " + original.getId()
                            + " (" + original.getCliente().getNombre() + ") | Motivo: " + r.getMotivo());
                }
            }
            recorrido = recorrido.getSiguiente();
        }
    }

    public static void consulta5(Lista<Transaccion> lista) {
        titulo("C5 - COMISIONES GANADAS EN EL DIA (sin reversadas)");
        double total = 0;
        Nodo<Transaccion> actual = lista.getCabeza();
        while (actual != null) {
            Transaccion t = actual.getDato();
            if (t instanceof CambioDivisa && t.esEfectiva()) {
                CambioDivisa cambio = (CambioDivisa) t;
                total = total + t.getCliente().calcularComision(cambio.getMontoDestino());
            }
            actual = actual.getSiguiente();
        }
        System.out.println("Total de comisiones: " + formato(total) + " COP");
    }

    public static void consulta6(Caja caja) {
        titulo("C6 - SALDO DE CAJA POR DIVISA");
        System.out.println(String.format("%-7s %18s %18s %18s", "Divisa", "Inicial", "Final", "Diferencia"));
        for (int i = 0; i < DIVISAS.length; i++) {
            String d = DIVISAS[i];
            System.out.println(String.format("%-7s %18s %18s %18s", d,
                    formato(caja.consultarSaldoInicial(d)),
                    formato(caja.consultarSaldo(d)),
                    formato(caja.diferenciaSaldo(d))));
        }
    }

    public static void consulta7(Lista<Transaccion> lista) {
        titulo("C7 - TOP 3 TRANSACCIONES POR MONTO (COP)");
        Lista<Transaccion> ordenada = ordenarPorMonto(lista);
        if (ordenada.estaVacia()) {
            System.out.println("No hay transacciones completadas.");
            return;
        }
        Transaccion mayor = mayorTransaccion(lista);
        System.out.println("La mayor: " + mayor.getId() + " con "
                + formato(mayor.getMontoEquivalenteCOP()) + " COP");
        Nodo<Transaccion> actual = ordenada.getCabeza();
        int puesto = 1;
        while (actual != null && puesto <= 3) {
            Transaccion t = actual.getDato();
            System.out.println("   " + puesto + ". " + t.getId() + " | " + t.getCliente().getNombre()
                    + " | " + formato(t.getMontoEquivalenteCOP()) + " COP");
            actual = actual.getSiguiente();
            puesto++;
        }
    }

    public static void consulta8(Lista<Transaccion> lista) {
        titulo("C8 - CLIENTE MAS FRECUENTE");
        Cliente c = clienteMasFrecuente(lista);
        if (c == null) {
            System.out.println("No hay operaciones registradas.");
            return;
        }
        int suyas = contarOperaciones(lista, c.getId());
        int total = totalOperaciones(lista);
        double porcentaje = suyas * 100.0 / total;
        System.out.println(c.getId() + " - " + c.getNombre() + " [" + c.getTipo() + "]");
        System.out.println("Operaciones: " + suyas + " de " + total
                + " (" + String.format("%.1f", porcentaje) + " %)");
    }

    public static void consulta9(Lista<Transaccion> lista, String desde, String hasta) {
        titulo("C9 - OPERACIONES ENTRE " + desde + " Y " + hasta);
        Lista<Transaccion> enRango = transaccionesEnRango(lista, desde, hasta);
        if (enRango.estaVacia()) {
            System.out.println("No hay operaciones en ese rango.");
            return;
        }
        Nodo<Transaccion> actual = enRango.getCabeza();
        while (actual != null) {
            System.out.println(actual.getDato().toLinea());
            actual = actual.getSiguiente();
        }
    }

    public static void consulta10(String rutaArchivo, String origen, String destino, String fecha) {
        titulo("C10 - HISTORIAL DE LA TASA " + origen + "/" + destino + " (" + fecha + ")");
        int encontrados = 0;
        int omitidas = 0;
        try {
            BufferedReader lector = new BufferedReader(new FileReader(rutaArchivo));
            String linea = lector.readLine();
            while (linea != null) {
                if (!linea.trim().isEmpty()) {
                    String[] campos = linea.split(";");
                    if (campos.length != 6) {
                        omitidas++;
                    } else if (campos[0].startsWith(fecha) && campos[1].equals(origen)
                            && campos[2].equals(destino)) {
                        System.out.println("   " + campos[0] + " | " + campos[3] + " -> "
                                + campos[4] + " | por " + campos[5]);
                        encontrados++;
                    }
                }
                linea = lector.readLine();
            }
            lector.close();
        } catch (IOException e) {
            System.out.println("No se pudo leer el archivo " + rutaArchivo);
            return;
        }
        if (encontrados == 0) {
            System.out.println("No hay cambios para esa tasa en la fecha indicada.");
        }
        if (omitidas > 0) {
            System.out.println("(Se omitieron " + omitidas + " lineas corruptas)");
        }
    }

    public static void consulta11(Lista<Transaccion> lista) {
        titulo("C11 - COMISIONES POR TIPO DE CLIENTE");
        String[] tipos = {"GENERAL", "PREFERENCIAL", "EMPRESARIAL"};
        double total = 0;
        for (int i = 0; i < tipos.length; i++) {
            total = total + comisionesPorTipo(lista, tipos[i]);
        }
        if (total == 0) {
            System.out.println("No hay comisiones registradas.");
            return;
        }
        for (int i = 0; i < tipos.length; i++) {
            double valor = comisionesPorTipo(lista, tipos[i]);
            System.out.println(String.format("   %-13s %15s COP  (%.1f %%)",
                    tipos[i], formato(valor), valor * 100 / total));
        }
        System.out.println("   Total: " + formato(total) + " COP");
    }

    public static void consulta12(Lista<Cliente> clientes, Lista<Transaccion> lista) {
        titulo("C12 - CLIENTES EMPRESARIALES");
        Lista<Cliente> empresas = listarPorTipoCliente(clientes, "EMPRESARIAL");
        if (empresas.estaVacia()) {
            System.out.println("No hay clientes empresariales.");
            return;
        }
        Nodo<Cliente> actual = empresas.getCabeza();
        while (actual != null) {
            Cliente c = actual.getDato();
            double totalCOP = 0;
            Nodo<Transaccion> nodoT = lista.getCabeza();
            while (nodoT != null) {
                Transaccion t = nodoT.getDato();
                if (t.esEfectiva() && t.getCliente().getId().equals(c.getId())) {
                    totalCOP = totalCOP + t.getMontoEquivalenteCOP();
                }
                nodoT = nodoT.getSiguiente();
            }

            ClienteEmpresarial empresa = (ClienteEmpresarial) c;
            System.out.println("   " + c.getId() + " | " + c.getNombre() + " | NIT "
                    + empresa.getNit() + " | Total: " + formato(totalCOP) + " COP");
            actual = actual.getSiguiente();
        }
    }
}
