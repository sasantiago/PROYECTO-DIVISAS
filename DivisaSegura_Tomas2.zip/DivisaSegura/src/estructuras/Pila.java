package estructuras;

public class Pila<T> {
    private Nodo<T> tope;
    private int tamano;

    public Pila() {
        tope = null;
        tamano = 0;
    }

    public void apilar(T dato) {
        Nodo<T> nuevo = new Nodo<>(dato);
        nuevo.setSiguiente(tope);
        tope = nuevo;
        tamano++;
    }

    public T desapilar() {
        if (tope == null) {
            return null;
        }
        T dato = tope.getDato();
        tope = tope.getSiguiente();
        tamano--;
        return dato;
    }

    public T cima() {
        if (tope == null) {
            return null;
        }
        return tope.getDato();
    }

    public boolean estaVacia() {
        return tope == null;
    }

    public int tamano() {
        return tamano;
    }

    public void vaciar() {
        tope = null;
        tamano = 0;
    }
}
