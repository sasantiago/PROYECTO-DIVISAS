package estructuras;

public class Lista<T> {
    private Nodo<T> cabeza;
    private Nodo<T> ultimo;
    private int tamano;

    public Lista() {
        cabeza = null;
        ultimo = null;
        tamano = 0;
    }

    public void agregar(T dato) {
        Nodo<T> nuevo = new Nodo<>(dato);
        if (cabeza == null) {
            cabeza = nuevo;
            ultimo = nuevo;
        } else {
            ultimo.setSiguiente(nuevo);
            ultimo = nuevo;
        }
        tamano++;
    }

    public boolean insertarEn(int posicion, T dato) {
        if (posicion < 0 || posicion > tamano) {
            return false;
        }
        Nodo<T> nuevo = new Nodo<>(dato);
        if (posicion == 0) {
            nuevo.setSiguiente(cabeza);
            cabeza = nuevo;
            if (ultimo == null) {
                ultimo = nuevo;
            }
        } else if (posicion == tamano) {
            ultimo.setSiguiente(nuevo);
            ultimo = nuevo;
        } else {
            Nodo<T> anterior = cabeza;
            for (int i = 0; i < posicion - 1; i++) {
                anterior = anterior.getSiguiente();
            }
            nuevo.setSiguiente(anterior.getSiguiente());
            anterior.setSiguiente(nuevo);
        }
        tamano++;
        return true;
    }

    public T obtener(int posicion) {
        if (posicion < 0 || posicion >= tamano) {
            return null;
        }
        Nodo<T> actual = cabeza;
        for (int i = 0; i < posicion; i++) {
            actual = actual.getSiguiente();
        }
        return actual.getDato();
    }

    public T eliminar(int posicion) {
        if (posicion < 0 || posicion >= tamano) {
            return null;
        }
        T eliminado;
        if (posicion == 0) {
            eliminado = cabeza.getDato();
            cabeza = cabeza.getSiguiente();
            if (cabeza == null) {
                ultimo = null;
            }
        } else {
            Nodo<T> anterior = cabeza;
            for (int i = 0; i < posicion - 1; i++) {
                anterior = anterior.getSiguiente();
            }
            Nodo<T> objetivo = anterior.getSiguiente();
            eliminado = objetivo.getDato();
            anterior.setSiguiente(objetivo.getSiguiente());
            if (objetivo == ultimo) {
                ultimo = anterior;
            }
        }
        tamano--;
        return eliminado;
    }

    public boolean estaVacia() {
        return cabeza == null;
    }

    public int tamano() {
        return tamano;
    }

    public Nodo<T> getCabeza() {
        return cabeza;
    }
}
